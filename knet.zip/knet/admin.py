from django.contrib import admin
from .models import KnetPayment

@admin.register(KnetPayment)
class KnetPaymentAdmin(admin.ModelAdmin):
    list_display = ['tracking_id', 'amount', 'status', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['tracking_id', 'payment_id']
    readonly_fields = ['created_at', 'updated_at']